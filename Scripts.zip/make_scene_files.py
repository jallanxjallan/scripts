#!/home/jeremy/Scripts/Python3.6Env/bin/python
# -*- coding: utf-8 -*-
#
#  module.py
#  
#  Copyright 2019 Jeremy Allan <jeremy@jeremyallan.com>

import sys 
import os
import plac
from pathlib import Path
from collections import defaultdict

sys.path.append('/home/jeremy/Scripts/Library')

STORY_PREFIX = '# '
SCENE_PREFIX = '## '

base_dir = '/home/jeremy/Documents/one_man_air_force/screenplay/scenes/'
source_doc = '/home/jeremy/Documents/one_man_air_force/screenplay/scenes.md'

def main():
    base_path = Path(base_dir)
    story = None
    scene = None
    scenes = defaultdict(lambda: defaultdict(list))
    for line in Path(source_doc).read_text().split('\n'):
        if len(line.strip()) == 0:
            continue
        elif line.startswith(STORY_PREFIX):
                story = line.lstrip(STORY_PREFIX).title()
        elif line.startswith(SCENE_PREFIX):
                scene = line.lstrip(SCENE_PREFIX).title()
        else:
            scenes[story][scene].append(line)
    
    for story in scenes:
        story_path = Path(base_dir, story)
        if not story_path.exists():
            story_path.mkdir()
        for scene, content in scenes[story].items():
            scene_path = Path(base_dir, story_path, scene).with_suffix('.md')
            scene_path.write_text('\n'.join(content))
    
if __name__ == '__main__':
    plac.call(main)
