#!/home/jeremy/Scripts/Python3.6Env/bin/python
# -*- coding: utf-8 -*-
#
#  module.py
#  
#  Copyright 2019 Jeremy Allan <jeremy@jeremyallan.com>

import sys 
import os
import plac
import re
from pathlib import Path
from collections import defaultdict
import spacy

from spacy.matcher import Matcher
from spacy.attrs import POS

sys.path.append('/home/jeremy/Scripts/Library')

from storage.cherrytree import CherryTree


nlp = spacy.load("en_core_web_sm")

matcher = Matcher(nlp.vocab)
matcher.add("NounVerb", None, [{POS: "VERB"}, {POS: "ADJ"}, {POS: "VERB"}])

def write_node_file(node_path, text):
    if not node_path.parent.exists():
        node_path.parent.mkdir(parents=True)
    node_path.with_suffix('.txt').write_text(text)
    

def parse_list_item(item):
    doc = nlp(item)
    sent = next((s for s in doc.sents if len(s) > 3), None)
    if not sent:
        return
    ne = next((e.text for e in sent.ents), sent[0].text)
    ps = [t for t in sent if t.pos_ in ('NOUN', 'VERB')]
    if ps:
        ps = ' '.join((p.text for p in ps[:10]))
    else:
        ps = sent[1:10].text
    return re.sub('\s+', ' ', ' '.join((ne, ps)))
    

def main(ct_filepath, base_dir):
    path_base = Path(Path.cwd(), base_dir)
    with CherryTree(ct_filepath) as ct:
        for node in ct.all_nodes():
            try:
                ancestor_nodes = [a.name for a in node.ancestors]
                if not ancestor_nodes[0] == 'Stories':
                    continue
            except IndexError:
                continue
            node_path = path_base.joinpath(*ancestor_nodes)
            items = list(node.txt.list_items('numbered'))
            if items:
                for item in items:
                    item_name = parse_list_item(item)
                    write_node_file(node_path.joinpath(node.name, item_name), item or 'No notes')
            else:
                write_node_file(node_path.joinpath(node.name), node.txt.text or 'No notes')
                    

    
if __name__ == '__main__':
    plac.call(main)
