#!/home/jeremy/Python3.6Env/bin/python
# -*- coding: utf-8 -*-
#
#  script.py
#  
#  Copyright 2019 Jeremy Allan <jeremy@jeremyallan.com>

import sys 
import os
import plac
from pathlib import Path

sys.path.append('/home/jeremy/Library')

def main(config):
    base_path = Path.cwd()
    config_path = base_path.joinpath(config).with_suffix('yaml')
    c = yaml.load(Path(config) + 'ya
    pass
    
if __name__ == '__main__':
    plac.call(main)
